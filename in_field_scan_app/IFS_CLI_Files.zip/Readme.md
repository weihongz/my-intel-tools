Version 1.5.4
Second beta release
Known Issues: N/A
Changes: SAF changed to IFS (in field scan) everywhere